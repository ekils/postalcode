#coding=utf-8
from os.path import dirname, join


_package_root = dirname(__file__)
_chp_csv_path = join(_package_root, 'zip_code.xlsx')
